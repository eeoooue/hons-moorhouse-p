candidate A = single state (iterated local search)
candidate B = pop-based (mew lambda evolutionary strategy)